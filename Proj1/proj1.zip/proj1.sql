-- comp9311 19T3 Project 1
--
-- MyMyUNSW Solutions


-- Q1:
create or replace view Q1(courseid, code)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q2:
create or replace view Q2(unswid,name,class_num)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q3:
create or replace view Q3(classid, course, room)
as 
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q4:
create or replace view Q4(unswid, name)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

--Q5:
create or replace view Q5(num_student))
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q6:
create or replace view Q6(semester, max_num_student)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q7:
create or replace view Q7(course, avgmark, semester)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q8: 
create or replace view Q8(num)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q9:
create or replace view Q9(unswid, name)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q10:
create or replace view Q10(unswid, longname, num, rank)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q11:
create or replace view Q11(unswid, name)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q12:
create or replace view Q12(unswid, name, program, academic_standing)
as
--... SQL statements, possibly using other views/functions defined by you ...
;
